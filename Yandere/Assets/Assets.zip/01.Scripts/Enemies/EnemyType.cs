using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EnemyType
{
      Normal,
      Elite,
      Boss
   
}
public enum EnemyAttackType
{
   AttackType_A,
   AttackType_B,
   AttackType_C,
   AttackType_D
}
