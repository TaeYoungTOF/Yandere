using UnityEngine;

[CreateAssetMenu(fileName = "LevelupData_BurstingGaze", menuName = "Skill/SkillData/BurstingGaze", order = 2)]
public class LevelupData_BurstingGaze : SkillData_Active
{
    [Header("Upgradable")]
    [Range (0, 90)] public float angle;
}
